require 'spec_helper'

describe ProfileController do

end
