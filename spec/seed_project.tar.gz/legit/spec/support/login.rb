module LoginMacros
  def login_as role
    @user = User.create(:email => "user#{User.count}@mail.com", 
                        :password => "123456",
                        :password_confirmation => "123456")
    visit new_user_session_path
    fill_in "Email", :with => @user.email
    fill_in "Password", :with => "123456"
    click_button "Sign in"
  end
end
