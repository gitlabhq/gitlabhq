Legit::Application.routes.draw do
  resources :projects do
    member do 
      get "tree"
      get "blob"
      get "team"
    end
    resources :commits
    resources :team_members
  end

  match "profile", :to => "profile#index"

  resources :keys

  devise_for :users
  root :to => "projects#index"
end
