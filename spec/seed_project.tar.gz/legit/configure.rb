def prepare
  root_path = File.dirname(__FILE__) 
  puts " == Starting..."
  `rvm gemset create legit`
  `rvm use 1.9.2@legit --create`

  Dir.chdir("/tmp")
  Dir.chdir(root_path)

  puts " == gemset created"
  `gem install bundler`
  puts " == install bundler"
  `bundle install`
  puts " == bundle install"
  `rake db:setup`
  `rake db:setup RAILS_ENV=test`
  `rake db:setup RAILS_ENV=production`
  puts " == db with seeds created"
  puts " == Done! Now you can start server"
end

prepare
