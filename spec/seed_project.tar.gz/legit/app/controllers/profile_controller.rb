class ProfileController < ApplicationController
  def index

  end
end
