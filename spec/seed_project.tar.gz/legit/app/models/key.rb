class Key < ActiveRecord::Base
  belongs_to :user
end
